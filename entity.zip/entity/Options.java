package com.webinfer.affiliate.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;


/**
 * The persistent class for the option database table.
 * 
 */
@Entity
@NamedQuery(name="Option.findAll", query="SELECT o FROM Options o")
@SequenceGenerator(name="OptionIDGenerator", initialValue=1, allocationSize=100)
public class Options implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="OptionIDGenerator")
	private Long id;

	@CreationTimestamp
	private Date createtime;

	@CreatedBy
	private String createuser;

	private String name;

	private Boolean retired;

	@UpdateTimestamp
	private Date updatetime;

	@LastModifiedBy
	private String updateuser;

	//bi-directional many-to-one association to Optiontype
	@ManyToOne
	@JoinColumn(name="subtype")
	private Optiontype optiontype;

	//bi-directional many-to-one association to Productoption
    @OneToMany(fetch=FetchType.LAZY, mappedBy="option")
	private List<Productoption> productoptions;

	public Options() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Timestamp createtime) {
		this.createtime = createtime;
	}

	public String getCreateuser() {
		return this.createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getRetired() {
		return this.retired;
	}

	public void setRetired(Boolean retired) {
		this.retired = retired;
	}

	public Date getUpdatetime() {
		return this.updatetime;
	}

	public void setUpdatetime(Timestamp updatetime) {
		this.updatetime = updatetime;
	}

	public String getUpdateuser() {
		return this.updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

	public Optiontype getOptiontype() {
		return this.optiontype;
	}

	public void setOptiontype(Optiontype optiontype) {
		this.optiontype = optiontype;
	}

	public List<Productoption> getProductoptions() {
		return this.productoptions;
	}

	public void setProductoptions(List<Productoption> productoptions) {
		this.productoptions = productoptions;
	}

	public Productoption addProductoption(Productoption productoption) {
		getProductoptions().add(productoption);
		productoption.setOption(this);

		return productoption;
	}

	public Productoption removeProductoption(Productoption productoption) {
		getProductoptions().remove(productoption);
		productoption.setOption(null);

		return productoption;
	}

}