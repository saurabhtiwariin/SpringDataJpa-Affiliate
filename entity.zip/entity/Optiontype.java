package com.webinfer.affiliate.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
/**
 * The persistent class for the optiontype database table.
 * 
 */
@Entity
@NamedQuery(name="Optiontype.findAll", query="SELECT o FROM Optiontype o")
@SequenceGenerator(name="OptiontypeIDGenerator", initialValue=1, allocationSize=100)
public class Optiontype implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id 
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="OptiontypeIDGenerator")
	private Long id;

	private String code;

    @CreationTimestamp
    private Date createtime;

	@CreatedBy
	private String createuser;

	private String name;

	private Boolean retired;

	@UpdateTimestamp
    private Date updatetime;

	@LastModifiedBy
	private String updateuser;

	//bi-directional many-to-one association to Option
	@OneToMany(mappedBy="optiontype")
	private List<Options> options;

	public Optiontype() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getCreateuser() {
		return this.createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getRetired() {
		return this.retired;
	}

	public void setRetired(Boolean retired) {
		this.retired = retired;
	}

	public Date getUpdatetime() {
		return this.updatetime;
	}

	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}

	public String getUpdateuser() {
		return this.updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

	public List<Options> getOptions() {
		return this.options;
	}

	public void setOptions(List<Options> options) {
		this.options = options;
	}

	public Options addOption(Options option) {
		getOptions().add(option);
		option.setOptiontype(this);

		return option;
	}

	public Options removeOption(Options option) {
		getOptions().remove(option);
		option.setOptiontype(null);

		return option;
	}

}