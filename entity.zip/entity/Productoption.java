package com.webinfer.affiliate.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;


/**
 * The persistent class for the productoption database table.
 * 
 */
@Entity
@NamedQuery(name="Productoption.findAll", query="SELECT p FROM Productoption p")
@SequenceGenerator(name="ProductoptionIDGenerator", initialValue=1, allocationSize=100)
public class Productoption implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ProductoptionIDGenerator")
	private Long id;

	private int items;

	private double optionPriceDelta;

	private int sold;

	//bi-directional many-to-one association to Product
	@ManyToOne(fetch=FetchType.LAZY) 
	private Products product;

	//bi-directional many-to-one association to Option
	@ManyToOne(fetch=FetchType.LAZY) 
	private Options option;

	public Productoption() {
	}

	public int getItems() {
		return this.items;
	}

	public void setItems(int items) {
		this.items = items;
	}

	public double getOptionPriceDelta() {
		return this.optionPriceDelta;
	}

	public void setOptionPriceDelta(double optionPriceDelta) {
		this.optionPriceDelta = optionPriceDelta;
	}

	public int getSold() {
		return this.sold;
	}

	public void setSold(int sold) {
		this.sold = sold;
	}

	public Products getProduct() {
		return this.product;
	}

	public void setProduct(Products product) {
		this.product = product;
	}

	public Options getOption() {
		return this.option;
	}

	public void setOption(Options option) {
		this.option = option;
	}

}