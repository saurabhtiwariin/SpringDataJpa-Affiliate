/**
 * 
 */
package com.webinfer.affiliate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.webinfer.affiliate.entity.Options;

/**
 * @author saura
 *
 */
@RepositoryRestResource(collectionResourceRel = "options",path="options")
public interface OptionsRepo extends JpaRepository<Options, Long> {

}
