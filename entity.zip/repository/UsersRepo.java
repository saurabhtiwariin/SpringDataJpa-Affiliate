/**
 * 
 */
package com.webinfer.affiliate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.webinfer.affiliate.entity.Users;

/**
 * @author saura
 *
 */
@RepositoryRestResource(collectionResourceRel = "users",path="users")
public interface UsersRepo extends JpaRepository<Users, Long> {

}
