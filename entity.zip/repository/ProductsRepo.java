/**
 * 
 */
package com.webinfer.affiliate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.webinfer.affiliate.entity.Products;

/**
 * @author saura
 *
 */
@RepositoryRestResource(collectionResourceRel = "products",path="products")
public interface ProductsRepo extends JpaRepository<Products, Long> {

}
