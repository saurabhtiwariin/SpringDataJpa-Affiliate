/**
 * 
 */
package com.webinfer.affiliate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.webinfer.affiliate.entity.Orderdetail;

/**
 * @author saura
 *
 */
@RepositoryRestResource(collectionResourceRel = "orderdetails",path="orderdetails")
public interface OrderDetailRepo extends JpaRepository<Orderdetail, Long> {

}
